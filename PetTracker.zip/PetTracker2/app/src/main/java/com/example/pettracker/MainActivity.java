package com.example.pettracker;


import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;


import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button buttonSubmitSwitch = findViewById(R.id.buttongo);

        buttonSubmitSwitch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Activity1();
            }
        }
        );
        //@Override
        //public void onClick(View v) {
        //  switch (v.getId()) {
        //  case R.id.sign_in_button:
        //    signIn();
        //    break;
                // ...
        //}
        //}

    //private void signIn() { google sign in
    //   Intent signInIntent = mGoogleSignInClient.getSignInIntent();
        //startActivityForResult(signInIntent, RC_SIGN_IN);
    // }

        }
    public void Activity1 (){
        Intent intent = new Intent(this,Scanned.class);
        startActivity(intent);
    }
}